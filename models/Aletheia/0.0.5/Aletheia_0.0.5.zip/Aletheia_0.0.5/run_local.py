#!/usr/bin/env python3
"""Aletheia 0.0.5 — одна команда на хосте: замер → набор → обучение →
досмотр → GGUF. Комплект живёт ЗДЕСЬ, в публичной зоне (папка модели);
приватное — набор из диалогов и его сборщик — живёт в репозитории-источнике
и сюда не кладётся: шаг data берёт набор по --data, либо находит сборщик в
соседнем клоне источника и запускает его там.

    python run_local.py                      # всё подряд, с возобновлением
    python run_local.py --only probe         # один шаг: probe|data|train|leak|gguf
    python run_local.py --data <папка с train.jsonl/val.jsonl>
    python run_local.py --base Qwen/Qwen2.5-3B-Instruct --max-len 512
    python run_local.py --variant t                # сборка 0.0.5t — учитель ОП-геометрии (набор data_t/, GGUF Aletheia-0.0.5t)
    python run_local.py --source <клон InvesePolar>  # где лежит клон источника (иначе ищется рядом; AIASA_SOURCE=… тоже принимается)
    python run_local.py --deploy                   # только развёртывание: недостающее ставится/клонируется, ничего не учится

Развёртывание с коррекцией недостачи (слово хоста 11.09: «необходимые компоненты
должны определяться наличием в системе и скачиваться из сети, если не обнаружены
локально»): шаг deploy идёт первым и сам добирает недостающее — модули Python
(pip), сборку torch с CUDA при карте NVIDIA (cu128), клон источника рядом
(git clone InvesePolar — набор лежит в нём: ENV/*/model/data/train.jsonl),
клон llama.cpp для шага gguf; что добрать не удалось — названо кодом и строкой,
не молча. Аргумент вида КЛЮЧ=ЗНАЧЕНИЕ в командной строке принимается как
переменная среды (`run_local.py AIASA_SOURCE=E:\\…\\InvesePolar`).

Каждый шаг пишет отметку в runs/LOCAL_STATE.json; повтор команды
продолжает с места остановки (--redo — повторить сделанное).
Пути: всё относительно ПАПКИ КОМПЛЕКТА (где лежит этот файл), а не текущей
папки оболочки — команда работает из любой папки: `python C:\\0.0.5\\run_local.py`.
llama.cpp ищется в папке комплекта, рядом с ней и по LLAMA_CPP; GGUF кладётся в
папку комплекта. Копия папки — своя: состояние другой папки распознаётся по
записанной в нём папке и отбрасывается.
Что прислать обратно (файлами): runs/LOCAL_STATE.json,
runs/aiasa-0.0.5/TRAIN_REPORT.json, runs/aiasa-0.0.5/merged/LEAK_TEST.json,
host_log.json. Веса (GGUF) — в Releases частями; в чат их не слать.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

if os.name == "nt":
    # Вывод в файл на Windows (`python run_local.py > log.txt`) шёл бы в кодировке
    # консоли (cp1251/cp866) и падал на «→» — пускач, который «не молчит», обязан
    # печатать при любом перенаправлении.
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

HERE = pathlib.Path(__file__).resolve().parent
RUNS = HERE / "runs"
STATE = RUNS / "LOCAL_STATE.json"
STEPS = ("probe", "data", "train", "leak", "gguf")
STAGE = "0.0.5"
#: Сборки (слово автора 10.09): "" — базовая; "t" — teacher, по умолчанию учитель ОП-геометрии
#: (набор data_t/ собирается сборщиком источника с флагом --teacher; системная подсказка учителя внутри набора).
VARIANTS = {"": "исполнитель проекта Ф-чисел", "t": "учитель ОП-геометрии: курс с нуля до задач высшей сложности"}
SOURCE_REPO = "InvesePolar"     # репозиторий-источник (приватный): там сборщик набора
SOURCE_URL = "https://github.com/dtba3a-del/InvesePolar"
LLAMA_URL = "https://github.com/ggml-org/llama.cpp"
NEEDED = ("torch", "transformers", "peft", "datasets", "accelerate")

#: Профиль хоста по VRAM: (порог GiB, база, max_len). 7B в 4 битах не входит в 4 GiB.
PROFILES = ((12, "Qwen/Qwen2.5-7B-Instruct", 2048), (6, "Qwen/Qwen2.5-3B-Instruct", 1024),
            (0, "Qwen/Qwen2.5-1.5B-Instruct", 1024))


LOCK = RUNS / "LOCK"
HEARTBEAT_S = 60          # строка о ходе не реже раза в минуту (письмо хоста 05.09: «молчаливое поведение не даёт информации»)


def rel(path) -> str:
    """Путь в состоянии — ОТНОСИТЕЛЬНО папки комплекта (письмо хоста 05.09:
    абсолютные пути ломают перенос и пробу — копия папки лезла в исходную)."""
    p = pathlib.Path(path)
    try:
        return str(p.resolve().relative_to(HERE))
    except ValueError:
        return str(p)


def absol(path, must_exist: str | None = None) -> pathlib.Path:
    """Относительный путь считается ОТ ПАПКИ КОМПЛЕКТА, не от текущей папки
    оболочки: `python C:\\0.0.5\\run_local.py --data data2` из любой папки
    значит `C:\\0.0.5\\data2`. Для входа (`must_exist` — имя файла, который
    обязан лежать внутри) допускается запасной вариант от текущей папки, если
    от папки комплекта его нет: команда, набранная «здесь», не отвергается."""
    p = pathlib.Path(path)
    if p.is_absolute():
        return p
    here = HERE / p
    if must_exist and not (here / must_exist).is_file():
        cwd = pathlib.Path.cwd() / p
        if (cwd / must_exist).is_file():
            return cwd.resolve()
    return here


def load() -> dict:
    if not STATE.is_file():
        return {"шаги": {}}
    try:
        st = json.loads(STATE.read_text(encoding="utf-8"))
    except ValueError:
        print(f"!! {STATE} нечитаем — начинаю заново")
        return {"шаги": {}}
    # Состояние другой папки (скопировано вместе с комплектом) — чужое: его
    # шаги относятся к другому процессу. Узнаётся по записанной папке, а не по
    # абсолютности путей: набор, собранный в соседнем клоне источника, лежит
    # вне комплекта законно и абсолютным путём. Сравнение путей — через
    # pathlib (на Windows без учёта регистра букв и с любым наклоном черты).
    own = st.get("папка")
    if own and pathlib.Path(own) != HERE:
        print(f"!! LOCAL_STATE.json записан в другой папке ({own}) — состояние чужое, начинаю заново в {HERE}")
        st = {"шаги": {}, "чужое состояние отброшено": {"папка": own, "шаги": st.get("шаги", {})}}
    return st


def save(st: dict) -> None:
    RUNS.mkdir(parents=True, exist_ok=True)
    st["папка"] = str(HERE)
    STATE.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")


def _alive(pid: int) -> bool:
    if os.name == "nt":
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"], capture_output=True, text=True).stdout
        return str(pid) in out
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def take_lock() -> bool:
    """Замок папки: второй запуск в той же папке отказывает, а не портит
    открытые на запись файлы идущего процесса. Копия папки — своя (пути
    относительные), ей замок не мешает."""
    RUNS.mkdir(parents=True, exist_ok=True)
    if LOCK.is_file():
        try:
            info = json.loads(LOCK.read_text(encoding="utf-8"))
        except ValueError:
            info = {}
        pid = int(info.get("pid", 0) or 0)
        if pid and _alive(pid):
            print(f"!! в этой папке уже идёт процесс pid {pid} с {info.get('с', '?')} — вторая копия не запускается.\n"
                  f"   Для пробы скопируйте папку целиком (пути относительные, состояние копии своё) или дождитесь конца;\n"
                  f"   ход текущего: python {HERE / pathlib.Path(__file__).name} --status")
            return False
        print(f"   замок от завершившегося процесса pid {pid} снят")
    LOCK.write_text(json.dumps({"pid": os.getpid(), "с": time.strftime("%Y-%m-%dT%H:%M:%S"), "папка": str(HERE)}, ensure_ascii=False), encoding="utf-8")
    return True


def release_lock() -> None:
    try:
        LOCK.unlink()
    except OSError:
        pass


def progress_line(out_dir) -> str:
    """Строка хода из PROGRESS.json, который пишет train_lora.py."""
    for cand in (absol(out_dir) / "PROGRESS.json", absol(out_dir) / "probe" / "PROGRESS.json"):
        if cand.is_file():
            try:
                pr = json.loads(cand.read_text(encoding="utf-8"))
            except ValueError:
                continue
            if pr.get("шаг") is not None and pr.get("всего"):
                eta = pr.get("осталось, с")
                return (f"{pr.get('этап', 'train')}: шаг {pr['шаг']}/{pr['всего']} ({100 * pr['шаг'] // max(pr['всего'], 1)} %), "
                        f"{pr.get('с/шаг', '?')} с/шаг, осталось ~{round(eta / 60) if eta else '?'} мин, loss {pr.get('loss', '?')}")
            return f"{pr.get('этап', '?')} ({pr.get('когда', '')})"
    return ""


def run(cmd: list, st: dict, step: str, cwd=None, out_dir=None) -> int:
    t0 = time.time()
    print(f"\n== шаг {step}: {' '.join(map(str, cmd))}")
    proc = subprocess.Popen([str(c) for c in cmd], cwd=cwd)
    last = t0
    while proc.poll() is None:
        time.sleep(5)
        if time.time() - last >= HEARTBEAT_S:
            last = time.time()
            pl = progress_line(out_dir) if out_dir else ""
            print(f"   [{time.strftime('%H:%M:%S')}] шаг {step} идёт {round((last - t0) / 60)} мин" + (f"; {pl}" if pl else ""), flush=True)
    rc = proc.returncode
    st["шаги"][step] = {"код": rc, "секунд": round(time.time() - t0), "когда": time.strftime("%Y-%m-%dT%H:%M:%S")}
    save(st)
    return rc


def sha256_file(path) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def status(a_out) -> int:
    st = load()
    print(f"папка: {HERE}")
    if LOCK.is_file():
        try:
            info = json.loads(LOCK.read_text(encoding="utf-8"))
            print(f"замок: pid {info.get('pid')} с {info.get('с')} — {'жив' if _alive(int(info.get('pid', 0) or 0)) else 'мёртв (снимется при следующем запуске)'}")
        except ValueError:
            print("замок: нечитаем")
    else:
        print("замок: нет (процесс не идёт)")
    for k, v in st.get("шаги", {}).items():
        print(f"  шаг {k}: код {v.get('код')} {v.get('когда', '')} {v.get('секунд', '')}")
    pl = progress_line(a_out)
    print("ход обучения:", pl or "PROGRESS.json нет (обучение не начиналось или папка --out другая)")
    if st.get("набор sha256"):
        print("набор:", st.get("data"), "sha256", st["набор sha256"])
    return 0


def host_profile() -> dict:
    """host_log.json после probe: есть ли CUDA, VRAM, выбор базы."""
    log_path = HERE / "host_log.json"
    if not log_path.is_file():
        return {}
    log = json.loads(log_path.read_text(encoding="utf-8"))
    smi = str(log.get("nvidia-smi", ""))
    vram = None
    if "MiB" in smi:
        for tok in smi.replace(",", " ").split():
            if tok.isdigit():
                vram = int(tok); break
    cuda = bool(log.get("cuda", {}).get("available")) if isinstance(log.get("cuda"), dict) else False
    prof = {"gpu": smi, "vram_MiB": vram, "cuda": cuda, "torch": log.get("torch"), "python": log.get("python")}
    gib = (vram or 0) / 1024
    for thr, base, max_len in PROFILES:
        if gib >= thr:
            prof["base"], prof["max_len"] = base, max_len
            break
    return prof


def missing_modules() -> list:
    """Модули комплекта, которые не ввозятся. Ловится любая ошибка ввоза, не
    только ImportError: после `pip --force-reinstall torch` (04.09) pip
    перетянул fsspec 2026.7.0 при требовании datasets fsspec<=2026.6.0 — такой
    разлад проявляется не отсутствием модуля, а ошибкой внутри ввоза."""
    out = []
    for m in ("torch", "transformers", "peft", "datasets", "accelerate"):
        try:
            __import__(m)
        except Exception as e:  # noqa: BLE001 — любая причина, поимённо
            out.append(m)
            msg = f"{type(e).__name__}: {e}"
            print(f"!! {m}: ввоз не удался — {msg[:200]}")
            if "fsspec" in msg:
                print('   лечится: pip install "fsspec[http]<=2026.6.0"')
    return out


def source_roots(explicit=None) -> list:
    """Где ищется клон источника: --source, AIASA_SOURCE, рядом с комплектом, над ним, в домашней, C:\\."""
    roots = []
    if explicit:
        roots.append(pathlib.Path(explicit))
    if os.environ.get("AIASA_SOURCE"):
        roots.append(pathlib.Path(os.environ["AIASA_SOURCE"]))
    roots += [HERE / SOURCE_REPO, HERE.parent / SOURCE_REPO]
    roots += [HERE.parents[3] / SOURCE_REPO] if len(HERE.parents) > 3 else []
    roots.append(pathlib.Path.home() / SOURCE_REPO)
    if os.name == "nt":
        roots.append(pathlib.Path("C:/") / SOURCE_REPO)
    seen, out = set(), []
    for r in roots:
        k = str(r).lower()
        if k not in seen:
            seen.add(k); out.append(r)
    return out


def find_source(explicit=None, variant: str = "") -> tuple:
    """(корень клона, папка набора, сборщик) — что нашлось; печатает, где искал и что там есть.

    Набор лежит В КЛОНЕ (ENV/*/model/data/train.jsonl — файл версионирован), поэтому
    сборщик запускать не нужно, если набор уже есть; сборщик нужен только для сборки t
    (data_t/ — производное) или когда набора в клоне нет."""
    data_name = "data_t" if variant == "t" else "data"
    for root in source_roots(explicit):
        if not root.is_dir():
            print(f"   источник: {root} — папки нет")
            continue
        data = sorted(root.glob(f"ENV/*/model/{data_name}/train.jsonl"))
        builder = sorted(root.glob("ENV/*/model/build_dataset.py"))
        env = sorted(root.glob("ENV/*"))
        print(f"   источник: {root} — папка есть; ENV/*: {len(env)}; {data_name}/train.jsonl: {'есть' if data else 'нет'}; сборщик: {'есть' if builder else 'нет'}")
        if data or builder:
            return root, (data[0].parent if data else None), (builder[0] if builder else None)
        print(f"   {root}: похоже на неполный клон (нет ENV/*/model) — клон надо обновить: git -C \"{root}\" pull")
    return None, None, None


def find_builder() -> pathlib.Path | None:
    return find_source()[2]


def _run_quiet(cmd: list, cwd=None) -> int:
    print("   $", " ".join(map(str, cmd)))
    try:
        return subprocess.call([str(c) for c in cmd], cwd=cwd)
    except OSError as e:
        print(f"   !! не запустилось: {e}")
        return 127


def deploy(a, st: dict) -> dict:
    """Развёртывание с коррекцией недостачи: что есть — проверено, чего нет — добирается из сети.
    Возвращает отчёт {компонент: состояние}; ничего не учит."""
    rep = {}
    py = sys.executable
    # 1. модули Python
    miss = missing_modules()
    if miss and not a.no_net:
        _run_quiet([py, "-m", "pip", "install", "--quiet", *miss, "bitsandbytes"])
        miss = missing_modules()
    rep["модули"] = "все на месте" if not miss else f"не хватает {miss}"
    # 2. torch с CUDA при карте NVIDIA
    prof = host_profile()
    if prof.get("vram_MiB") and not prof.get("cuda") and not a.cpu_ok and not a.no_net:
        _run_quiet([py, "-m", "pip", "install", "--quiet", "--force-reinstall", "--no-deps", "torch", "--index-url", "https://download.pytorch.org/whl/cu128"])
        rep["torch"] = "переставлен на cu128 — повторить probe"
    else:
        rep["torch"] = f"{prof.get('torch', '?')}, CUDA {prof.get('cuda')}" if prof else "probe не делался"
    # 3. клон источника (набор внутри)
    root, data, builder = find_source(a.source, a.variant)
    if root is None and not a.no_net:
        target = HERE / SOURCE_REPO
        if shutil.which("git") is None:
            rep["источник"] = "git не найден — поставить git (git-scm.com) либо положить клон рядом"
        else:
            rc = _run_quiet(["git", "clone", "--depth", "1", SOURCE_URL, str(target)])
            root, data, builder = find_source(str(target), a.variant) if rc == 0 else (None, None, None)
            rep["источник"] = f"клонирован в {target}" if root else f"клонирование не удалось (код {rc}): приватный репозиторий — нужен вход git (credential manager) либо клон рукой рядом"
    elif root is not None:
        rep["источник"] = f"{root} ({'набор есть' if data else 'набора нет'}, {'сборщик есть' if builder else 'сборщика нет'})"
    else:
        rep["источник"] = "не найден, сеть выключена (--no-net)"
    # 4. llama.cpp для gguf
    llama = find_llama()
    if llama is None and not a.no_net and shutil.which("git"):
        rc = _run_quiet(["git", "clone", "--depth", "1", LLAMA_URL, str(HERE / "llama.cpp")])
        llama = find_llama() if rc == 0 else None
        if llama is not None:
            _run_quiet([py, "-m", "pip", "install", "--quiet", "-r", str(llama / "requirements.txt")])
    rep["llama.cpp"] = str(llama) if llama else "нет (шаг gguf отложится; сборка: cmake -B llama.cpp/build -S llama.cpp && cmake --build llama.cpp/build --config Release)"
    rep["cmake"] = "есть" if shutil.which("cmake") else "нет — для llama-quantize поставить cmake (cmake.org) либо взять готовые двоичные файлы llama.cpp из Releases"
    st["развёртывание"] = rep; save(st)
    print("развёртывание:")
    for k, v in rep.items():
        print(f"   {k}: {v}")
    return rep


def find_llama() -> pathlib.Path | None:
    """Клон llama.cpp: в папке комплекта, рядом с ней, по LLAMA_CPP, в текущей папке.
    Прежде проверялась только текущая папка оболочки — из `C:\\` комплект в
    `C:\\0.0.5` своего клона не видел."""
    cands = [HERE / "llama.cpp", HERE.parent / "llama.cpp",
             pathlib.Path(os.environ["LLAMA_CPP"]) if os.environ.get("LLAMA_CPP") else None,
             pathlib.Path.cwd() / "llama.cpp"]
    for c in cands:
        if c is not None and (c / "convert_hf_to_gguf.py").is_file():
            return c.resolve()
    return None


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=STEPS)
    ap.add_argument("--data", default=None, help="папка с train.jsonl/val.jsonl (по умолчанию — data/ рядом либо сборщик источника)")
    ap.add_argument("--base", default=None, help="база; без флага — по профилю хоста (VRAM)")
    ap.add_argument("--max-len", type=int, default=None, help="без флага — по профилю хоста")
    ap.add_argument("--epochs", type=float, default=2.0)
    ap.add_argument("--out", default=None, help="папка прогона ОТНОСИТЕЛЬНО комплекта (по умолчанию runs/aiasa-0.0.5<вариант>)")
    ap.add_argument("--variant", default="", choices=sorted(VARIANTS), help="сборка: '' — базовая, t — учитель ОП-геометрии (набор data_t/, GGUF Aletheia-0.0.5t)")
    ap.add_argument("--cpu-ok", action="store_true", help="учить на CPU, даже если GPU есть, а CUDA в torch нет")
    ap.add_argument("--redo", action="store_true", help="повторить уже сделанные шаги")
    ap.add_argument("--status", action="store_true", help="показать ход и выйти (ничего не запускать)")
    ap.add_argument("--no-probe", action="store_true", help="не мерить скорость (3 шага) перед обучением")
    ap.add_argument("--max-hours", type=float, default=0, help="если оценка времени обучения больше — не начинать (0 — без предела)")
    ap.add_argument("--source", default=None, help="клон репозитория-источника (набор и сборщик внутри); иначе ищется рядом / AIASA_SOURCE")
    ap.add_argument("--deploy", action="store_true", help="только развёртывание с коррекцией недостачи (модули, torch cu128, клон источника, llama.cpp)")
    ap.add_argument("--no-net", action="store_true", help="ничего не скачивать: только проверить наличие")
    argv = list(sys.argv[1:] if argv is None else argv)
    for tok in list(argv):            # КЛЮЧ=ЗНАЧЕНИЕ в командной строке — переменная среды (хост 11.09 набрал AIASA_SOURCE=… аргументом)
        if "=" in tok and not tok.startswith("-") and tok.split("=", 1)[0].isidentifier():
            k, v = tok.split("=", 1); os.environ[k] = v; argv.remove(tok)
            print(f"   переменная среды из аргумента: {k}={v}")
    a = ap.parse_args(argv)
    if a.out is None:
        a.out = f"runs/aiasa-{STAGE}{a.variant}"
    if a.status:
        return status(a.out)
    if not take_lock():
        return 6
    try:
        return _main(a)
    finally:
        release_lock()


def _main(a) -> int:
    st = load()
    py = sys.executable
    if a.deploy or not st.get("развёртывание"):
        deploy(a, st)
        if a.deploy:
            return 0
    data_dir = absol(a.data if a.data else (st.get("data") or f"data{'_' + a.variant if a.variant else ''}"), must_exist="train.jsonl")
    if a.variant:
        print(f"сборка {STAGE}{a.variant}: {VARIANTS[a.variant]}")
        st["сборка"] = f"{STAGE}{a.variant}"
    steps = [a.only] if a.only else list(STEPS)
    for step in steps:
        if not a.redo and st["шаги"].get(step, {}).get("код") == 0 and step != "probe":
            print(f"== шаг {step}: уже сделан ({st['шаги'][step]['когда']}) — пропуск (--redo, чтобы повторить)")
            continue
        rc = 0
        if step == "probe":
            rc = run([py, HERE / "probe_host.py"], st, step)
            miss = missing_modules()
            if miss:
                print(f"!! не хватает модулей: {miss} — pip install {' '.join(miss)} bitsandbytes")
                st["не хватает"] = miss; save(st)
                if not a.only:
                    return 2
            prof = host_profile()
            st["профиль"] = prof; save(st)
            if prof:
                print(f"профиль хоста: GPU «{prof.get('gpu')}», VRAM {prof.get('vram_MiB')} MiB, CUDA в torch: {prof.get('cuda')} → база {prof.get('base')}, max_len {prof.get('max_len')}")
            if prof and prof.get("vram_MiB") and not prof.get("cuda") and not a.cpu_ok:
                print("!! CUDA-драйвер и карта NVIDIA есть (nvidia-smi отвечает), а УСТАНОВЛЕННАЯ СБОРКА torch — CPU (+cpu):")
                print("   карта простаивает (0 % в диспетчере), обучение пошло бы на CPU. Поставить сборку cu128")
                print("   (колёса для Python 3.13/3.14, Windows/Linux, есть):")
                print("   pip install --force-reinstall --no-deps torch --index-url https://download.pytorch.org/whl/cu128")
                print("   (--no-deps: меняется только torch; без него pip перетягивает fsspec и печатает красные строки о конфликтах —")
                print("   datasets требует fsspec[http]<=2026.6.0; лечится: pip install \"fsspec[http]<=2026.6.0\"; конфликты чужих пакетов —")
                print("   open-interpreter/starlette, selenium/urllib3 — комплекта не касаются)")
                print("   Вторая карта другого производителя (экранная) для CUDA невидима — выбирать устройство не нужно,")
                print("   torch cu128 увидит одну карту NVIDIA как device 0. Учить на CPU всё равно — флаг --cpu-ok (1.5B: часы)")
                st["шаги"][step] = {"код": 4, "почему": "torch без CUDA при наличии GPU"}; save(st)
                if not a.only:
                    return 4
        elif step == "data":
            if (data_dir / "train.jsonl").is_file():
                print(f"== шаг data: набор есть — {data_dir}")
                st["шаги"][step] = {"код": 0, "когда": time.strftime("%Y-%m-%dT%H:%M:%S"), "откуда": str(data_dir)}
            else:
                root, src_data, builder = find_source(a.source, a.variant)
                if src_data is not None and (src_data / "train.jsonl").is_file():
                    data_dir = src_data
                    print(f"== шаг data: набор взят из клона источника — {data_dir}")
                    st["шаги"][step] = {"код": 0, "когда": time.strftime("%Y-%m-%dT%H:%M:%S"), "откуда": str(data_dir)}
                elif builder is None:
                    print(f"!! набора нет ({data_dir / 'train.jsonl'}) и клон источника не найден или неполон (см. строки «источник:» выше): "
                          f"python {HERE / 'run_local.py'} --deploy добирает клон сам; либо --source <путь к клону>; либо --data <папка с train.jsonl>")
                    st["шаги"][step] = {"код": 5, "почему": "нет набора и сборщика"}; save(st)
                    if not a.only:
                        return 5
                    continue
                else:
                    rc = run([py, "-B", builder] + (["--teacher"] if a.variant == "t" else []), st, step, cwd=builder.parent)
                    data_dir = builder.parent / ("data_t" if a.variant == "t" else "data")
            st["data"] = rel(data_dir)
            tr = data_dir / "train.jsonl"
            if tr.is_file():
                h = sha256_file(tr)
                if st.get("набор sha256") and st["набор sha256"] != h:
                    print(f"   набор изменился с прошлого запуска ({st['набор sha256']} → {h}): обучение пойдёт на новом наборе")
                    st["набор прежний sha256"] = st["набор sha256"]
                st["набор sha256"] = h
                st["набор байт"] = tr.stat().st_size
            save(st)
        elif step == "train":
            prof = st.get("профиль") or host_profile()
            base = a.base or prof.get("base") or PROFILES[0][1]
            max_len = a.max_len or prof.get("max_len") or PROFILES[0][2]
            out_dir = absol(a.out)
            common = ["--base", base, "--data", data_dir, "--epochs", str(a.epochs), "--max-len", str(max_len)]
            if not a.no_probe and not st.get("замер скорости"):
                # Замер скорости: 3 шага, затем оценка всего прогона (письмо хоста 05.09:
                # «от 0,3 до 60 токенов в минуту — разница в 200 раз; неудачная конфигурация — пара лет»)
                rc = run([py, "-B", HERE / "train_lora.py", *common, "--out", out_dir / "probe", "--steps", "3", "--no-merge"], st, "train-probe", out_dir=out_dir / "probe")
                pr_path = out_dir / "probe" / "PROGRESS.json"
                if rc == 0 and pr_path.is_file():
                    pr = json.loads(pr_path.read_text(encoding="utf-8"))
                    sps, full = pr.get("с/шаг"), pr.get("полных шагов")
                    if sps and full:
                        hours = sps * full / 3600
                        st["замер скорости"] = {"с/шаг": sps, "полных шагов": full, "часов": round(hours, 1)}; save(st)
                        print(f"   оценка: {sps} с/шаг × {full} шагов ≈ {hours:.1f} ч обучения" + (" — много: меньше база/max_len/epochs" if hours > 72 else ""))
                        if a.max_hours and hours > a.max_hours:
                            print(f"!! оценка {hours:.1f} ч больше предела --max-hours {a.max_hours}: обучение не начато")
                            st["шаги"]["train"] = {"код": 7, "почему": f"оценка {hours:.1f} ч > {a.max_hours}"}; save(st)
                            return 7
                elif rc != 0:
                    print("!! замер скорости не удался — обучение всё равно начинается (без оценки времени)")
            rc = run([py, "-B", HERE / "train_lora.py", *common, "--out", out_dir], st, step, out_dir=out_dir)
        elif step == "leak":
            rc = run([py, "-B", HERE / "leak_test.py", "--model", absol(a.out) / "merged", "--data", data_dir / "train.jsonl", "--n", "100"], st, step)
            if rc != 0:
                print("!! досмотр не пройден: веса НЕ публиковать (см. LEAK_TEST.json)")
        elif step == "gguf":
            llama = find_llama()
            if llama is None:
                print(f"!! llama.cpp не найден ни в {HERE}, ни рядом с ней, ни по LLAMA_CPP: cd {HERE} && git clone https://github.com/ggml-org/llama.cpp "
                      "&& pip install -r llama.cpp/requirements.txt && cmake -B llama.cpp/build -S llama.cpp && cmake --build llama.cpp/build --config Release -j")
                st["шаги"][step] = {"код": 3, "почему": "нет llama.cpp"}; save(st)
                continue
            rc = run([py, "-B", HERE / "export_gguf.py", absol(a.out) / "merged", f"Aletheia-{STAGE}{a.variant}", "--llama", llama, "--outdir", HERE], st, step)
        if rc != 0 and not a.only:
            print(f"!! шаг {step} завершился кодом {rc}; остальное не запускалось. Повтор: python {HERE / pathlib.Path(__file__).name}")
            return rc
    print("\nитог:", json.dumps(st["шаги"], ensure_ascii=False))
    print(f"прислать: {STATE}, {absol(a.out) / 'TRAIN_REPORT.json'}, {absol(a.out) / 'merged' / 'LEAK_TEST.json'}, {HERE / 'host_log.json'}")
    print(f"ход в любой момент: python {HERE / pathlib.Path(__file__).name} --status")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
